## Flight Parser CLI APP

Uses the flight parser library to parse flights from input files into output files.

### Installation

npm install

See install instructions for the flight parser library in it's readme.

### Usage

node index.js path_to_input_file [path_to_output_file]