## Flight Parser

A library for parsing flights

### Installation

npm install -g grunt-cli;npm install -g mocha;npm install -g watch;npm install -g nodemon;npm install

### Usage

var flightParser = require('./flight-parser');
flightParser(data, function(outputData){
	
});

### Build

npm run build

### Test

npm test